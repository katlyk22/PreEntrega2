from setuptools import setup

setup(name="KatiaLylyk",
      version="1.0",
      description="Paquete de clientes",
      author="Katia Lylyk",
      author_email="katialylyk22@gmail.com.com",
      packages=["Paquete"])